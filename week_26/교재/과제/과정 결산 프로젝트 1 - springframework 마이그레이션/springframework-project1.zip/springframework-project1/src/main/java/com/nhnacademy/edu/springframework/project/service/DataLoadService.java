package com.nhnacademy.edu.springframework.project.service;

public interface DataLoadService {
    void loadAndMerge();
}
