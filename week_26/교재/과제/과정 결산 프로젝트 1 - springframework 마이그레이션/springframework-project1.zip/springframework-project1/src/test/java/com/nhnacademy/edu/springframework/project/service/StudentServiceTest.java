package com.nhnacademy.edu.springframework.project.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentServiceTest {

    @Test
    void getPassedStudents() {
    }

    @Test
    void getStudentsOrderByScore() {
    }
}